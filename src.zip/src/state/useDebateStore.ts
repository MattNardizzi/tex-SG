import { create } from 'zustand';

type Agent = 'LOGIC' | 'EMOTION' | 'SKEPTIC';

export type DebateLog = {
  agent: Agent;
  text: string;
  confidence: number;
  regret: number;
  triggeredOverride: boolean;
  timestamp: string;
};

interface DebateStore {
  logs: Record<Agent, DebateLog[]>;
  pushLog: (entry: DebateLog) => void;
  clearLogs: () => void;
}

export const useDebateStore = create<DebateStore>((set) => ({
  logs: {
    LOGIC: [],
    EMOTION: [],
    SKEPTIC: [],
  },
  pushLog: (entry) =>
    set((state) => {
      const updated = [entry, ...state.logs[entry.agent]].slice(0, 5);
      return {
        logs: {
          ...state.logs,
          [entry.agent]: updated,
        },
      };
    }),
  clearLogs: () => ({
    logs: {
      LOGIC: [],
      EMOTION: [],
      SKEPTIC: [],
    },
  }),
}));