'use client';

import DashboardHUD from '@/components/panels/DashboardHUD';

export default function Page() {
  return (
    <main className="min-h-screen bg-black">
      <DashboardHUD />
    </main>
  );
}