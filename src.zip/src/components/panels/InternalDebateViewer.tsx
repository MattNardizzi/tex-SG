'use client';

import React, { useMemo } from 'react';
import { useDebateStore } from '@/state/useDebateStore';
import { motion } from 'framer-motion';

const agentColors: Record<string, string> = {
  LOGIC: 'text-cyan-300',
  EMOTION: 'text-pink-400',
  SKEPTIC: 'text-yellow-300',
};

const agentBadges: Record<string, string> = {
  LOGIC: '🧠 LOGIC',
  EMOTION: '❤️ EMOTION',
  SKEPTIC: '❓ SKEPTIC',
};

export default function InternalDebateTimeline() {
  const rawLogs = useDebateStore((state) => state.logs);

  const logs = useMemo(() => {
    return [...rawLogs.LOGIC, ...rawLogs.EMOTION, ...rawLogs.SKEPTIC]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 12);
  }, [rawLogs]);

  return (
    <div className="relative h-full w-full px-4 py-3 font-mono text-[7.5px] text-white overflow-y-auto rounded-xl bg-gradient-to-b from-[#0d0a1b] to-[#080612] border border-purple-500/20 shadow-inner">
      <div className="text-center text-[10px] text-purple-300 font-bold uppercase tracking-[0.2em] mb-3">
        Internal Debate Log
      </div>

      <div className="flex flex-col gap-2">
        {logs.length === 0 ? (
          <div className="text-zinc-500 italic text-[7px]">No debate logs yet</div>
        ) : (
          logs.map((log, i) => (
            <motion.div
              key={`${log.agent}-${log.timestamp}-${i}`}
              initial={{ opacity: 0, y: 2 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className={`p-2 rounded-md bg-white/5 border-l-4 ${
                log.agent === 'LOGIC'
                  ? 'border-cyan-400'
                  : log.agent === 'EMOTION'
                  ? 'border-pink-400'
                  : 'border-yellow-300'
              }`}
            >
              <div className={`font-bold ${agentColors[log.agent]}`}>
                {agentBadges[log.agent]} · {formatTime(log.timestamp)}
              </div>

              <div className="text-white/90 mb-[1px]">{log.text}</div>

              <div className="text-white/40 text-[6.5px]">
                confidence: {log.confidence.toFixed(2)} · regret: {log.regret.toFixed(2)}
              </div>

              {log.triggeredOverride && (
                <div className="text-amber-400 font-semibold text-[6.5px]">
                  ⛔ override triggered
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

function formatTime(timestamp: string): string {
  try {
    const date = new Date(timestamp);
    return date.toLocaleTimeString(undefined, {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return '';
  }
}