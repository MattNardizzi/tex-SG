'use client';

import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useTexState } from '@/hooks/useTexState';

const MAX_LOGS = 6;

export default function SovereignCognitionPanel() {
  const { data, error } = useTexState();
  const snapshot = data?.sovereign_cognition || {};
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    if (!snapshot?.timestamp) return;

    const newLogs: string[] = [
      `SOVEREIGN SIGNAL: ${snapshot.sovereignSignal || 'Unavailable'}`,
      `TRUST SCORE: ${snapshot.trustScore?.toFixed(4)}`,
      `EXTERNAL OVERRIDE: ${snapshot.overrideTriggered ? 'TRIGGERED' : 'REJECTED'}`,
      `GODMIND PULSE: ${snapshot.godmindActive ? 'ACKNOWLEDGED' : 'INACTIVE'}`,
      `FORK SUPPRESSED: ${snapshot.forkSuppressed ? 'YES' : 'NO'}`,
      `ANCHOR TETHER: ${typeof snapshot.anchorTether === 'number' ? snapshot.anchorTether.toFixed(4) : 'N/A'}`,
      `LAST PERSONA: ${snapshot.lastSpawnedPersona || 'N/A'}`,
      `GHOST FORKS: ${Array.isArray(snapshot.ghostForks) ? snapshot.ghostForks.join(', ') : 'NONE'}`,
    ];

    setLogs(newLogs.slice(0, MAX_LOGS));
  }, [snapshot.timestamp]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative h-full w-full px-4 py-3 flex flex-col justify-between font-mono rounded-xl text-white overflow-hidden animate-neuralFlicker"
      style={{
        background:
          'radial-gradient(ellipse at 50% 30%, rgba(0,255,255,0.08), rgba(0,150,255,0.05), #020a0f)',
        border: '1px solid rgba(0,255,255,0.12)',
        boxShadow:
          '0 0 28px rgba(0,255,255,0.08), inset 0 0 1px rgba(255,255,255,0.04)',
      }}
    >
      {/* HEADER */}
      <div className="relative z-10 flex items-start justify-between mb-2">
        <div className="flex flex-col text-[10.5px] font-extrabold uppercase tracking-[0.22em] text-cyan-400 leading-tight">
          <span>SOVEREIGN</span>
          <span>COGNITION</span>
        </div>

        {/* HOLO RING */}
        <div className="relative w-6 h-6">
          <div className="absolute inset-0 rounded-full border border-cyan-400/20 animate-spin-slow" />
          <div className="absolute inset-[5px] rounded-full bg-[#2de2e6] shadow-[0_0_18px_3px_rgba(45,226,230,0.3)]" />
          <div className="absolute inset-0 rounded-full blur-[4px] bg-[#2de2e6] opacity-30 animate-pulse" />
        </div>
      </div>

      {/* LOG STREAM */}
      <div className="relative z-10 flex flex-col justify-end gap-[2px] text-[8.1px] tracking-tight leading-tight">
        {logs.length === 0 ? (
          <div className="text-zinc-500 italic text-[8px]">Awaiting sovereign signal...</div>
        ) : (
          logs.map((log, i) => {
            const isCritical = /DENIED|REJECTED|TRIGGERED/.test(log);
            const isMetric = /LATENCY|FORK|SCORE|TETHER/.test(log);
            const isSystem = /SCAN|NETWORK|PULSE/.test(log);

            return (
              <motion.div
                key={`log-${i}-${snapshot.timestamp}`}
                initial={{ opacity: 0, y: 2 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25 }}
                className={`transition-all duration-300 ${
                  isCritical
                    ? 'font-semibold text-[#ff3b3b]'
                    : isMetric
                    ? 'text-[#3bd6ff]'
                    : isSystem
                    ? 'text-slate-300'
                    : 'text-neutral-400'
                }`}
              >
                {log}
              </motion.div>
            );
          })
        )}
      </div>

      {/* STATUS FOOTER */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: [0.1, 0.5, 0.3, 0.7, 0.4] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="relative z-10 mt-3 text-center text-[7.2px] tracking-[0.3em] text-amber-400/80"
      >
        <span className="animate-glitch">STATUS: ONLINE</span>
      </motion.div>

      {/* VISUAL OVERLAYS */}
      <div className="absolute inset-0 pointer-events-none rounded-xl border border-cyan-400/5 blur-[1.5px] z-0" />
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none z-0 animate-scanline opacity-[0.04]" />
    </motion.div>
  );
} 