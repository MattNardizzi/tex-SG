'use client';

import React, { useEffect, useState } from 'react';

type TickerData = {
  [symbol: string]: {
    price: number;
    change: number | null;
    direction: 'up' | 'down' | 'neutral';
  };
};

const MarketTicker = () => {
  const [data, setData] = useState<TickerData>({});

  useEffect(() => {
    const ws = new WebSocket('ws://localhost:8000/ws/polygon');

    ws.onmessage = (event) => {
      try {
        const update = JSON.parse(event.data);
        setData((prev) => ({ ...prev, ...update }));
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    };

    return () => {
      ws.close();
    };
  }, []);

  return (
    <div className="p-4 bg-white border rounded shadow">
      <h2 className="text-xl font-semibold mb-2">📈 Live Market Ticker</h2>
      {Object.keys(data).length === 0 ? (
        <p className="text-gray-500">Waiting for data...</p>
      ) : (
        <ul className="space-y-1">
          {Object.entries(data).map(([symbol, { price, change, direction }]) => (
            <li key={symbol} className="flex items-center justify-between">
              <span className="font-medium">{symbol.toUpperCase()}</span>
              <span>${price.toFixed(2)}</span>
              <span
                className={
                  direction === 'up'
                    ? 'text-green-600'
                    : direction === 'down'
                    ? 'text-red-600'
                    : 'text-gray-500'
                }
              >
                {change !== null ? `${change.toFixed(2)}%` : '--'} ({direction})
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MarketTicker;