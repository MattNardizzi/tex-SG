'use client'

import { useState } from 'react'

export default function SovereignTextbox() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<{ sender: 'user' | 'tex', text: string }[]>([])

  const sendMessage = async () => {
    if (!input.trim()) return

    const updated = [...messages, { sender: 'user', text: input }]
    setMessages(updated)

    const reply = `[Tex] Response to: "${input}"`
    setMessages([...updated, { sender: 'tex', text: reply }])
    setInput('')
  }

  return (
    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 w-[72%] z-50 font-grotesk">
      <div className="bg-black/60 border border-[#cccccc]/20 rounded-2xl px-6 pt-2 pb-2 shadow-[0_0_24px_#cccccc33] backdrop-blur-md">

        {/* Message Log */}
        <div className="max-h-36 overflow-y-auto text-xs text-white space-y-1.5 mb-2 px-1 font-normal">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`${msg.sender === 'user' ? 'text-cyan-400' : 'text-gray-300'}`}
            >
              <strong>{msg.sender === 'user' ? 'You' : 'Tex'}:</strong> {msg.text}
            </div>
          ))}
        </div>

        {/* Input + Glowing Button */}
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Speak to Tex..."
            autoCorrect="on"
            autoCapitalize="sentences"
            className="flex-1 text-xs font-normal bg-black/40 border border-[#cccccc]/20 rounded-md px-3 py-1 text-white placeholder-[#cccccc] placeholder:text-xs focus:outline-none focus:ring-1 focus:ring-[#cccccc] font-grotesk shadow-[0_0_12px_#cccccc44]"
          />

          <button
            onClick={sendMessage}
            className="w-[24px] h-[24px] rounded-full relative animate-pulse bg-[#1a1a1a] shadow-[0_0_12px_#ccccccaa]"
            aria-label="Send"
          >
            <svg
              width="100%"
              height="100%"
              viewBox="0 0 100 100"
              className="text-[#cccccc]"
            >
              <circle
                cx="50"
                cy="50"
                r="44"
                stroke="currentColor"
                strokeWidth="5"
                fill="none"
                strokeDasharray="260"
                strokeDashoffset="10"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}