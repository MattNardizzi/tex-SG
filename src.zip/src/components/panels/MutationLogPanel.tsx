'use client'

import { useEffect, useState } from 'react'

export default function MutationLogPanel() {
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    const interval = setInterval(() => {
      const newLog = generateLog()
      setLogs((prev) => [newLog, ...prev.slice(0, 2)])
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="absolute top-6 left-6 z-40">
      <div className="relative flex flex-col gap-1 bg-black/25 border border-white/10 backdrop-blur-sm rounded-md px-3 py-2 shadow-[inset_0_0_4px_#ffffff08,_0_0_10px_#ffffff10] max-w-[220px]">

        {/* Accent Bar */}
        <div className="absolute left-0 top-0 h-full w-[2px] bg-gradient-to-b from-cyan-400/40 to-transparent rounded-l-md" />

        {/* Log Items */}
        {logs.map((log, idx) => (
          <span
            key={idx}
            className="text-[10px] text-white/80 font-light leading-snug whitespace-normal break-words pl-[4px]"
          >
            {log}
          </span>
        ))}
      </div>
    </div>
  )
}

function generateLog() {
  const samples = [
    'Agent 0: aggression spike → 0.63',
    'Agent 2: curiosity spike → 0.74',
    'Memory stored: bias = aggressive',
    'Memory stored: fear ↑, resolve ↑',
    'Trait rewrite: greed suppressed',
    'Emotion path split → anger | hope',
    'Cortex divergence: Agent 3',
    'Swarm snapshot: 22:47:01',
  ]
  return samples[Math.floor(Math.random() * samples.length)]
}