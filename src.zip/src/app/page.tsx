'use client';

import { Canvas } from '@react-three/fiber';
import TexScene from '@/components/3d/TexScene'; // or whatever your R3F scene is
import MutationLogPanel from '@/components/ui/MutationLogPanel';
import SovereignStatusPanel from '@/components/ui/SovereignStatusPanel';
import SovereignTextbox from '@/components/ui/SovereignTextbox';

export default function MainPage() {
  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      {/* Your 3D Canvas */}
      <Canvas>
        <TexScene />
      </Canvas>

      {/* UI Overlay Panels */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        {/* Top left: Log */}
        <div className="absolute top-4 left-4 pointer-events-auto">
          <MutationLogPanel />
        </div>

        {/* Top right: Status */}
        <div className="absolute top-4 right-4 pointer-events-auto">
          <SovereignStatusPanel />
        </div>

        {/* Bottom center: Textbox */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-auto">
          <SovereignTextbox />
        </div>
      </div>
    </div>
  );
}