'use client'

import SpineCanvas from '@/components/Spine/SpineCanvas'
import SovereignTextbox from '@/components/SovereignTextbox'
import MutationLogPanel from '@/components/panels/MutationLogPanel'
import SovereignStatusPanel from '@/components/panels/SovereignStatusPanel'

export default function Home() {
  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black font-grotesk">
      {/* Left Cognitive Feed */}
      <MutationLogPanel />

      {/* Right Forkstream HUD */}
      <SovereignStatusPanel className="absolute top-6 right-6" />

      {/* 3D Sovereign Spine */}
      <SpineCanvas />

      {/* User Interaction Box */}
      <SovereignTextbox />
    </main>
  )
}