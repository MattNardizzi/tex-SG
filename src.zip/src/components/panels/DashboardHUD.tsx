'use client';

import React from 'react';
import SovereignCognitionPanel from './SovereignCognitionPanel';
import InternalDebateViewer from './InternalDebateViewer';
import QuantumAutonomy from './QuantumAutonomy';
import AwarenessStream from './AwarenessStream';
import GlassCortexPanel from './GlassCortexPanel';
import MultiverseGhoststream from './MultiverseGhoststream';
import ForecastRiskGrid from './ForecastRiskGrid';
import NeuroGenesisFork from './NeuroGenesisFork';
import CognitionCorePanel from '../ui/CognitionCorePanel';
import MarketTicker from '@/components/ui/MarketTicker';

export default function DashboardHUD() {
  return (
    <div className="w-screen h-screen bg-black text-white font-mono overflow-hidden">

      {/* 🔝 Market Ticker HUD Band */}
      <div className="h-6 w-full bg-gradient-to-r from-[#030c0f] via-[#041216]/90 to-[#030c0f] border-b border-cyan-400/10 backdrop-blur-sm shadow-[inset_0_-1px_0_rgba(0,255,255,0.05)] z-50">
        <MarketTicker />
      </div>

      {/* 🔳 3x3 Command Grid */}
      <div className="h-[calc(100vh-1.5rem)] grid grid-cols-3 grid-rows-3 gap-4 px-6 py-6">

        {/* 🧠 Top Row */}
        <div className="h-full w-full">
          <SovereignCognitionPanel />
        </div>
        <div className="h-full w-full">
          <InternalDebateViewer />
        </div>
        <div className="h-full w-full">
          <QuantumAutonomy />
        </div>

        {/* 🌐 Middle Row */}
        <div className="h-full w-full">
          <AwarenessStream />
        </div>
        <div className="h-full w-full">
          <CognitionCorePanel />
        </div>
        <div className="h-full w-full">
          <GlassCortexPanel />
        </div>

        {/* ⬇️ Bottom Row */}
        <div className="h-full w-full">
          <MultiverseGhoststream />
        </div>
        <div className="h-full w-full">
          <ForecastRiskGrid />
        </div>
        <div className="h-full w-full">
          <NeuroGenesisFork />
        </div>
      </div>
    </div>
  );
}