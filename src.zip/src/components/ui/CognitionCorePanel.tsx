'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { motion, AnimatePresence } from 'framer-motion';

// 🔮 Neural shader (reactive background)
const NeuralReactorShader = dynamic(() => import('./NeuralReactorShader'), { ssr: false });

const thoughts = [
  "Simulating adversarial policy chain...",
  "Executing memory resonance patch alignment...",
  "Integrating shadow agent feedback loops...",
  "Reinforcing multiverse fork stability...",
  "Filtering anomaly signals in sentiment field...",
];

export default function CognitionCorePanel() {
  const [cycle, setCycle] = useState(32);
  const [thought, setThought] = useState(thoughts[0]);
  const [loopStability, setLoopStability] = useState(0.974);
  const [cognitiveDrift, setCognitiveDrift] = useState(-0.021);
  const [pulse, setPulse] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setCycle((c) => c + 1);
      setThought(thoughts[Math.floor(Math.random() * thoughts.length)]);
      setLoopStability((Math.random() * 0.02 + 0.97).toFixed(3));
      setCognitiveDrift(((Math.random() * 0.04 - 0.02)).toFixed(3));
      setPulse(true);
      setTimeout(() => setPulse(false), 600);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative h-full w-full rounded-xl border border-cyan-500/10 bg-black/60 shadow-[0_0_35px_rgba(0,255,255,0.05)] backdrop-blur overflow-hidden">
      
      {/* 🔮 Neural pulse background */}
      <div className="absolute inset-0 z-0">
        <NeuralReactorShader />
      </div>

      {/* 🌌 Pulse ring effect */}
      <AnimatePresence>
        {pulse && (
          <motion.div
            initial={{ scale: 0.6, opacity: 0.6 }}
            animate={{ scale: 1.4, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute top-1/2 left-1/2 z-10 w-28 h-28 rounded-full border border-cyan-300/30 bg-cyan-400/10 blur-xl -translate-x-1/2 -translate-y-1/2"
          />
        )}
      </AnimatePresence>

      {/* 🧠 Cognition HUD */}
      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-white font-mono px-6 py-5 text-xs md:text-sm">
        
        {/* Cycle */}
        <div className="tracking-widest text-[10px] text-cyan-300/80 mb-2">
          CYCLE: <span className="text-cyan-400">{String(cycle).padStart(4, '0')}</span>
        </div>

        {/* Thought */}
        <div className="max-w-sm text-center px-4 text-[13px] md:text-[14px] leading-snug font-semibold text-white/90 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={thought}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.35 }}
              className="bg-gradient-to-r from-cyan-400 via-white to-purple-400 bg-clip-text text-transparent drop-shadow-[0_0_0.35em_rgba(255,255,255,0.1)]"
            >
              “{thought}”
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Metrics */}
        <div className="mt-4 flex gap-10 text-white/70 tracking-wide text-[11px]">
          <div>
            Loop Stability:
            <span className="ml-1 text-emerald-400">{loopStability}</span>
          </div>
          <div>
            Cognitive Drift:
            <span className={`ml-1 ${parseFloat(cognitiveDrift) < 0 ? "text-red-400" : "text-yellow-300"}`}>
              {parseFloat(cognitiveDrift) < 0 ? "↓" : "↑"} {Math.abs(cognitiveDrift)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}