import { useEffect, useState } from 'react';

// === Panel-specific types ===

type SovereignCognition = {
  godmindActive: boolean;
  overrideTriggered: boolean;
  trustScore: number;
  forkSuppressed: boolean;
  anchorTether: number | string;
  lastSpawnedPersona: string;
  ghostForks: string[];
  sovereignSignal: string;
  timestamp: string;
};

type DebateEntry = {
  agent: string;
  text: string;
  confidence: number;
  regret: number;
  triggeredOverride: boolean;
  timestamp: string;
};

type InternalDebate = {
  entries: DebateEntry[];
  cycle?: number;
  timestamp: string;
};

// === Master Tex state ===
type TexState = {
  sovereign_cognition?: SovereignCognition;
  internal_debate?: InternalDebate;
  strategy_overview?: any;
  simulacrum_feed?: any;
  [key: string]: any;
};

// === Hook: useTexState ===
export function useTexState(pollInterval: number = 5000) {
  const [data, setData] = useState<TexState>({});
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchState = async () => {
      try {
        const res = await fetch("http://localhost:4242/tex-state");
        const json = await res.json();

        console.log("[TexState] ✅ Raw data received:", json);

        const wrapped: TexState = {
          ...json,
          sovereign_cognition: json.sovereign_cognition || json,
        };

        // 🔧 Fix anchorTether string issue (if present)
        const tether = wrapped.sovereign_cognition?.anchorTether;
        if (typeof tether === 'string') {
          const parsed = parseFloat(tether);
          if (!isNaN(parsed)) {
            wrapped.sovereign_cognition!.anchorTether = parsed;
          }
        }

        setData(wrapped);
        setError(null);
      } catch (e) {
        console.error("[TexState] ❌ Fetch error:", e);
        setError("Failed to fetch Tex state");
      }
    };

    fetchState();
    const interval = setInterval(fetchState, pollInterval);
    return () => clearInterval(interval);
  }, [pollInterval]);

  return { data, error };
}